# Git

## 1. Commands

| Command | Description |
|---|---|
|`git reset --soft HEAD^`| Uncommit last one |
|`git push origin +master`| Push the changes replacing the last commit |
