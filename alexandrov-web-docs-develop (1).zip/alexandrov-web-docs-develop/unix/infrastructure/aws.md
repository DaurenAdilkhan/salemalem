# AWS

### Useful packages
| Package | What it does |
| ------- | ------------ |
| [aws-shell](https://github.com/awslabs/aws-shell) | Shell where:<br>  - no need to type aws prefix<br>- autocompletion of commands and options |
